const mysql = require('mysql2');

// Veritabanı bağlantı havuzunu oluşturun (environment variables üzerinden alınacak)
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,  // Max bağlantı sayısı
    queueLimit: 0
});

// Veritabanı bağlantısını almak için promisify yapıyoruz
const promisePool = pool.promise();

// API'nin çalışacağı Lambda fonksiyonu
exports.handler = async (event) => {
    try {
        // Veritabanından yemekleri çekmek için sorgu
        const [rows] = await promisePool.query('SELECT * FROM Foods');

        // Lambda API'yi JSON formatında döndürüyor
        return {
            statusCode: 200,
            body: JSON.stringify({
                success: true,
                data: rows
            }),
        };
    } catch (error) {
        console.error('Veritabanı hatası:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                success: false,
                message: 'Veritabanına bağlanırken hata oluştu.'
            }),
        };
    }
};
